def calculate_sum(a, b): return a + b; print(calculate_sum(5, 3))
