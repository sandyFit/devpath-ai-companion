# This file makes the tests directory a Python package
# It allows for better imports in test files