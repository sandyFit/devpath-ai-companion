# 📝 Class-based TODO App

A simple class-based command-line TODO list in Python.

## Run it

```bash
python main.py
