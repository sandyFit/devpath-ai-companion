def hello(): print('Hello from Python')
