const data = [
    {
        id: "q-a1",
        question: "What is AI",
        answer: "Artificial Intelligence is ......."
    },
    {
        id: "q-a1",
        question: "What is AI",
        answer: "Artificial Intelligence is ......."
    },
    {
        id: "q-a1",
        question: "What is AI",
        answer: "Artificial Intelligence is ......."
    },
    {
        id: "q-a1",
        question: "What is AI",
        answer: "Artificial Intelligence is ......."
    },
    {
        id: "q-a1",
        question: "What is AI",
        answer: "Artificial Intelligence is ......."
    },

]
